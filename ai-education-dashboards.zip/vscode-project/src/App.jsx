import { useState } from "react";
import EducationAnalytics from "./EducationAnalytics";
import FeedbackDashboard from "./FeedbackDashboard";
import LogisticRegressionDashboard from "./LogisticRegressionDashboard";

const apps = [
  {
    id: "feedback",
    label: "Feedback Dashboard",
    icon: "📊",
    desc: "Positive & Negative student feedback analytics",
    component: FeedbackDashboard,
  },
  {
    id: "education",
    label: "Education Analytics",
    icon: "🎓",
    desc: "AI-powered student feedback analyzer",
    component: EducationAnalytics,
  },
  {
    id: "logreg",
    label: "Logistic Regression",
    icon: "σ",
    desc: "ML model training & evaluation dashboard",
    component: LogisticRegressionDashboard,
  },
];

export default function App() {
  const [active, setActive] = useState(null);

  if (active) {
    const App = apps.find((a) => a.id === active).component;
    return (
      <div>
        <button
          onClick={() => setActive(null)}
          style={{
            position: "fixed",
            top: "16px",
            left: "16px",
            zIndex: 9999,
            background: "#1c1a17",
            color: "#f8f6f0",
            border: "none",
            borderRadius: "10px",
            padding: "8px 16px",
            cursor: "pointer",
            fontSize: "13px",
            fontWeight: "700",
            boxShadow: "0 4px 16px #00000040",
          }}
        >
          ← Back
        </button>
        <App />
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f0c29 0%, #1a1a3e 100%)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "'Georgia', serif",
        padding: "40px 24px",
      }}
    >
      <div style={{ textAlign: "center", marginBottom: "48px" }}>
        <div style={{ fontSize: "42px", marginBottom: "12px" }}>🎓</div>
        <h1
          style={{
            fontSize: "32px",
            fontWeight: "800",
            color: "#f0eaff",
            margin: "0 0 8px",
          }}
        >
          AI Education Suite
        </h1>
        <p style={{ color: "#a78bfa", fontSize: "14px", margin: 0 }}>
          Select a dashboard to launch
        </p>
      </div>

      <div
        style={{
          display: "flex",
          gap: "24px",
          flexWrap: "wrap",
          justifyContent: "center",
          maxWidth: "900px",
        }}
      >
        {apps.map((app) => (
          <button
            key={app.id}
            onClick={() => setActive(app.id)}
            style={{
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: "20px",
              padding: "32px 28px",
              width: "260px",
              cursor: "pointer",
              textAlign: "center",
              transition: "all 0.2s",
              color: "#e8e0f0",
              fontFamily: "inherit",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "rgba(255,255,255,0.1)";
              e.currentTarget.style.transform = "translateY(-4px)";
              e.currentTarget.style.boxShadow =
                "0 12px 40px rgba(124,58,237,0.3)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "rgba(255,255,255,0.05)";
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "none";
            }}
          >
            <div style={{ fontSize: "36px", marginBottom: "14px" }}>
              {app.icon}
            </div>
            <div
              style={{ fontSize: "16px", fontWeight: "700", marginBottom: "8px" }}
            >
              {app.label}
            </div>
            <div style={{ fontSize: "12px", color: "#a78bfa", lineHeight: 1.6 }}>
              {app.desc}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
