import { useState, useRef } from "react";

const SAMPLE_FEEDBACK = `Student 1 (Rating: 4/5): The teacher explains concepts clearly most of the time. Sometimes the pace is too fast and I struggle to keep up. Overall a good experience.

Student 2 (Rating: 2/5): Lectures are very hard to follow. The teacher jumps between topics without clear transitions. I often leave class more confused than when I arrived.

Student 3 (Rating: 5/5): Best teacher I've had! Very engaging, uses real-world examples, and always makes sure we understand before moving on. Very approachable for questions.

Student 4 (Rating: 3/5): The content is interesting but the delivery is monotonous. I find it hard to stay engaged during long lectures. Would appreciate more interactive activities.

Student 5 (Rating: 4/5): Good at explaining difficult topics. Sometimes the assignments feel disconnected from what we cover in class. More alignment would be helpful.

Student 6 (Rating: 1/5): The teacher seems unprepared at times and dismisses student questions. The attitude can be discouraging. I dread going to class.

Student 7 (Rating: 5/5): Extremely knowledgeable and passionate about the subject. Makes complex ideas accessible. Always willing to help after class too.

Student 8 (Rating: 3/5): Pacing is the main issue. We rush through important topics but spend too long on basics. Needs better time management in lectures.

Student 9 (Rating: 4/5): Clear communication, well-structured lessons. Would love more visual aids and multimedia in the lectures to break the monotony.

Student 10 (Rating: 2/5): The course is very difficult and there's not enough support provided. Office hours are rarely available and emails go unanswered for days.`;

const SYSTEM_PROMPT = `You are an AI-powered education analytics assistant designed to analyze student feedback for teachers.
Analyze the student feedback and generate a structured report.

Return ONLY valid JSON in this exact format, no other text:
{
  "overall_sentiment": {
    "positive_percentage": number,
    "neutral_percentage": number,
    "negative_percentage": number,
    "summary": "Brief professional summary"
  },
  "key_themes": [
    {
      "theme": "Theme name",
      "description": "Explanation",
      "frequency": "High/Medium/Low"
    }
  ],
  "strengths": ["List of strengths"],
  "areas_for_improvement": ["List of issues"],
  "representative_quotes": ["Short anonymized student quotes"],
  "recommendations": ["Actionable suggestions for the teacher"]
}

Guidelines:
- Be objective and avoid bias
- Focus on patterns, not individual opinions
- Keep insights concise but meaningful
- Professional academic tone
- Extract 3-5 items for each array field
- representative_quotes should be short paraphrased versions, not exact quotes`;

export default function App() {
  const [feedback, setFeedback] = useState(SAMPLE_FEEDBACK);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("sentiment");
  const reportRef = useRef(null);

  const analyzeData = async () => {
    setLoading(true);
    setError(null);
    setReport(null);
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: `Analyze this student feedback:\n\n${feedback}` }],
        }),
      });
      const data = await response.json();
      const raw = data.content.map(i => i.text || "").join("");
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setReport(parsed);
      setTimeout(() => reportRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    } catch (err) {
      setError("Analysis failed. Please check your feedback input and try again.");
    } finally {
      setLoading(false);
    }
  };

  const sentimentColor = (type) => {
    if (type === "positive") return "#22c55e";
    if (type === "neutral") return "#f59e0b";
    return "#ef4444";
  };

  const freqColor = (freq) => {
    if (freq === "High") return "#ef4444";
    if (freq === "Medium") return "#f59e0b";
    return "#22c55e";
  };

  const tabs = [
    { id: "sentiment", label: "Sentiment", icon: "📊" },
    { id: "themes", label: "Themes", icon: "🔍" },
    { id: "strengths", label: "Strengths", icon: "💪" },
    { id: "improvements", label: "Improvements", icon: "⚠️" },
    { id: "quotes", label: "Quotes", icon: "💬" },
    { id: "recommendations", label: "Actions", icon: "✅" },
  ];

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0f0c29 0%, #1a1a3e 50%, #0f0c29 100%)",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#e8e0f0",
      padding: "0",
    }}>
      {/* Header */}
      <div style={{
        background: "rgba(255,255,255,0.03)",
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        padding: "28px 40px",
        display: "flex",
        alignItems: "center",
        gap: "16px",
      }}>
        <div style={{
          width: "44px", height: "44px", borderRadius: "12px",
          background: "linear-gradient(135deg, #7c3aed, #a855f7)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "22px", boxShadow: "0 4px 20px rgba(124,58,237,0.4)"
        }}>🎓</div>
        <div>
          <div style={{ fontSize: "22px", fontWeight: "700", letterSpacing: "-0.5px", color: "#f0eaff" }}>
            EduInsight Analytics
          </div>
          <div style={{ fontSize: "12px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginTop: "2px" }}>
            AI-Powered Student Feedback Analyzer
          </div>
        </div>
      </div>

      <div style={{ maxWidth: "960px", margin: "0 auto", padding: "40px 24px" }}>
        {/* Input Section */}
        <div style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: "20px",
          padding: "32px",
          marginBottom: "32px",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
            <label style={{ fontSize: "15px", fontWeight: "600", color: "#c4b5fd" }}>
              📝 Student Feedback Input
            </label>
            <span style={{ fontSize: "12px", color: "#6b7280" }}>
              {feedback.split('\n').filter(l => l.trim()).length} entries
            </span>
          </div>
          <textarea
            value={feedback}
            onChange={e => setFeedback(e.target.value)}
            rows={10}
            style={{
              width: "100%",
              background: "rgba(0,0,0,0.3)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "12px",
              padding: "16px",
              color: "#d1d5db",
              fontSize: "13.5px",
              lineHeight: "1.7",
              resize: "vertical",
              outline: "none",
              boxSizing: "border-box",
              fontFamily: "'Courier New', monospace",
            }}
            placeholder="Paste student feedback here. Each entry on a new line. Ratings are optional (e.g. Rating: 4/5)"
          />
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "16px" }}>
            <button
              onClick={analyzeData}
              disabled={loading || !feedback.trim()}
              style={{
                background: loading ? "rgba(124,58,237,0.4)" : "linear-gradient(135deg, #7c3aed, #a855f7)",
                border: "none",
                borderRadius: "12px",
                padding: "14px 32px",
                color: "white",
                fontSize: "15px",
                fontWeight: "600",
                cursor: loading ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                boxShadow: loading ? "none" : "0 4px 20px rgba(124,58,237,0.4)",
                transition: "all 0.2s",
                letterSpacing: "0.3px",
              }}
            >
              {loading ? (
                <>
                  <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⟳</span>
                  Analyzing...
                </>
              ) : (
                <><span>🔬</span> Analyze Feedback</>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div style={{
            background: "rgba(239,68,68,0.1)",
            border: "1px solid rgba(239,68,68,0.3)",
            borderRadius: "12px",
            padding: "16px 20px",
            color: "#fca5a5",
            marginBottom: "24px",
          }}>⚠️ {error}</div>
        )}

        {/* Report */}
        {report && (
          <div ref={reportRef}>
            {/* Sentiment Bar */}
            <div style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "20px",
              padding: "28px 32px",
              marginBottom: "24px",
            }}>
              <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                Overall Sentiment
              </div>
              <div style={{ display: "flex", gap: "24px", marginBottom: "20px", flexWrap: "wrap" }}>
                {[
                  { label: "Positive", val: report.overall_sentiment.positive_percentage, type: "positive" },
                  { label: "Neutral", val: report.overall_sentiment.neutral_percentage, type: "neutral" },
                  { label: "Negative", val: report.overall_sentiment.negative_percentage, type: "negative" },
                ].map(s => (
                  <div key={s.type} style={{ flex: "1", minWidth: "100px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                      <span style={{ fontSize: "13px", color: "#9ca3af" }}>{s.label}</span>
                      <span style={{ fontSize: "16px", fontWeight: "700", color: sentimentColor(s.type) }}>{s.val}%</span>
                    </div>
                    <div style={{ height: "8px", borderRadius: "99px", background: "rgba(255,255,255,0.06)" }}>
                      <div style={{
                        height: "100%", borderRadius: "99px",
                        width: `${s.val}%`,
                        background: sentimentColor(s.type),
                        transition: "width 1s ease",
                      }} />
                    </div>
                  </div>
                ))}
              </div>
              <p style={{ fontSize: "14px", color: "#c4b5fd", lineHeight: "1.7", margin: "0", fontStyle: "italic" }}>
                {report.overall_sentiment.summary}
              </p>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", gap: "8px", marginBottom: "20px", flexWrap: "wrap" }}>
              {tabs.map(t => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  style={{
                    background: activeTab === t.id ? "linear-gradient(135deg, #7c3aed, #a855f7)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${activeTab === t.id ? "transparent" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: "99px",
                    padding: "8px 18px",
                    color: activeTab === t.id ? "white" : "#9ca3af",
                    fontSize: "13px",
                    cursor: "pointer",
                    fontFamily: "inherit",
                    display: "flex", alignItems: "center", gap: "6px",
                    transition: "all 0.2s",
                  }}
                >
                  {t.icon} {t.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "20px",
              padding: "28px 32px",
            }}>

              {activeTab === "themes" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Key Themes Identified
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                    {report.key_themes.map((t, i) => (
                      <div key={i} style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.07)",
                        borderRadius: "12px",
                        padding: "16px 20px",
                        display: "flex",
                        gap: "16px",
                        alignItems: "flex-start",
                      }}>
                        <span style={{
                          background: freqColor(t.frequency) + "22",
                          color: freqColor(t.frequency),
                          border: `1px solid ${freqColor(t.frequency)}44`,
                          borderRadius: "99px",
                          padding: "3px 12px",
                          fontSize: "11px",
                          fontWeight: "600",
                          whiteSpace: "nowrap",
                          marginTop: "2px",
                        }}>{t.frequency}</span>
                        <div>
                          <div style={{ fontWeight: "600", color: "#e8e0f0", marginBottom: "4px" }}>{t.theme}</div>
                          <div style={{ fontSize: "13.5px", color: "#9ca3af", lineHeight: "1.6" }}>{t.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "strengths" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Notable Strengths
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {report.strengths.map((s, i) => (
                      <div key={i} style={{
                        display: "flex", gap: "12px", alignItems: "flex-start",
                        padding: "14px 18px",
                        background: "rgba(34,197,94,0.07)",
                        border: "1px solid rgba(34,197,94,0.2)",
                        borderRadius: "10px",
                      }}>
                        <span style={{ color: "#22c55e", fontSize: "16px", marginTop: "1px" }}>✦</span>
                        <span style={{ fontSize: "14px", color: "#d1fae5", lineHeight: "1.6" }}>{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "improvements" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Areas for Improvement
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {report.areas_for_improvement.map((s, i) => (
                      <div key={i} style={{
                        display: "flex", gap: "12px", alignItems: "flex-start",
                        padding: "14px 18px",
                        background: "rgba(239,68,68,0.07)",
                        border: "1px solid rgba(239,68,68,0.2)",
                        borderRadius: "10px",
                      }}>
                        <span style={{ color: "#ef4444", fontSize: "16px", marginTop: "1px" }}>▲</span>
                        <span style={{ fontSize: "14px", color: "#fee2e2", lineHeight: "1.6" }}>{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "quotes" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Representative Student Voices
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                    {report.representative_quotes.map((q, i) => (
                      <div key={i} style={{
                        borderLeft: "3px solid #7c3aed",
                        paddingLeft: "18px",
                        paddingTop: "4px",
                        paddingBottom: "4px",
                      }}>
                        <div style={{ fontSize: "14px", color: "#c4b5fd", fontStyle: "italic", lineHeight: "1.7" }}>
                          "{q}"
                        </div>
                        <div style={{ fontSize: "11px", color: "#6b7280", marginTop: "6px" }}>— Anonymous Student</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "recommendations" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Actionable Recommendations
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {report.recommendations.map((r, i) => (
                      <div key={i} style={{
                        display: "flex", gap: "14px", alignItems: "flex-start",
                        padding: "16px 18px",
                        background: "rgba(168,85,247,0.08)",
                        border: "1px solid rgba(168,85,247,0.2)",
                        borderRadius: "10px",
                      }}>
                        <span style={{
                          background: "linear-gradient(135deg, #7c3aed, #a855f7)",
                          color: "white",
                          width: "24px", height: "24px",
                          borderRadius: "99px",
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: "12px", fontWeight: "700",
                          flexShrink: 0, marginTop: "1px",
                        }}>{i + 1}</span>
                        <span style={{ fontSize: "14px", color: "#e9d5ff", lineHeight: "1.7" }}>{r}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === "sentiment" && (
                <div>
                  <div style={{ fontSize: "11px", color: "#a78bfa", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "20px" }}>
                    Sentiment Breakdown
                  </div>
                  <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                    {[
                      { label: "Positive", val: report.overall_sentiment.positive_percentage, type: "positive", icon: "😊", desc: "Students expressed satisfaction" },
                      { label: "Neutral", val: report.overall_sentiment.neutral_percentage, type: "neutral", icon: "😐", desc: "Mixed or balanced feedback" },
                      { label: "Negative", val: report.overall_sentiment.negative_percentage, type: "negative", icon: "😟", desc: "Students expressed concerns" },
                    ].map(s => (
                      <div key={s.type} style={{
                        flex: "1", minWidth: "160px",
                        background: sentimentColor(s.type) + "11",
                        border: `1px solid ${sentimentColor(s.type)}33`,
                        borderRadius: "14px",
                        padding: "20px",
                        textAlign: "center",
                      }}>
                        <div style={{ fontSize: "28px", marginBottom: "8px" }}>{s.icon}</div>
                        <div style={{ fontSize: "32px", fontWeight: "700", color: sentimentColor(s.type) }}>{s.val}%</div>
                        <div style={{ fontWeight: "600", color: "#e8e0f0", marginTop: "4px" }}>{s.label}</div>
                        <div style={{ fontSize: "12px", color: "#9ca3af", marginTop: "6px" }}>{s.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {!report && !loading && (
          <div style={{ textAlign: "center", padding: "48px 24px", color: "#6b7280" }}>
            <div style={{ fontSize: "48px", marginBottom: "16px", opacity: "0.5" }}>📋</div>
            <div style={{ fontSize: "15px" }}>Paste student feedback above and click <strong style={{ color: "#a78bfa" }}>Analyze Feedback</strong> to generate your report</div>
            <div style={{ fontSize: "13px", marginTop: "8px", color: "#4b5563" }}>Sample feedback is pre-loaded — feel free to try it!</div>
          </div>
        )}

        {loading && (
          <div style={{ textAlign: "center", padding: "48px 24px" }}>
            <div style={{ fontSize: "40px", marginBottom: "16px", animation: "pulse 1.5s infinite" }}>🔬</div>
            <div style={{ color: "#a78bfa", fontSize: "15px" }}>Analyzing patterns across all feedback entries...</div>
            <div style={{ color: "#6b7280", fontSize: "13px", marginTop: "8px" }}>This may take a few seconds</div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        textarea:focus { border-color: rgba(124,58,237,0.5) !important; box-shadow: 0 0 0 3px rgba(124,58,237,0.15); }
        button:hover:not(:disabled) { transform: translateY(-1px); }
      `}</style>
    </div>
  );
}
