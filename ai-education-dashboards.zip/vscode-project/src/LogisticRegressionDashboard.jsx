import { useState, useEffect, useRef, useCallback } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, AreaChart, Area, BarChart, Bar, Cell } from "recharts";

// ── Logistic Regression Engine ──────────────────────────────────────────────
const sigmoid = z => 1 / (1 + Math.exp(-z));

function generateDataset(n = 200, seed = 42) {
  let s = seed;
  const rand = () => { s = (s * 1664525 + 1013904223) & 0xffffffff; return (s >>> 0) / 0xffffffff; };
  const randn = () => { let u = 0, v = 0; while (!u) u = rand(); while (!v) v = rand(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  const data = [];
  for (let i = 0; i < n; i++) {
    const label = rand() > 0.5 ? 1 : 0;
    const x1 = randn() * 1.5 + (label ? 2 : -2);
    const x2 = randn() * 1.5 + (label ? 1.5 : -1.5);
    const x3 = randn() * 1.2 + (label ? 1 : -1);
    const x4 = randn() * 2.0;
    data.push({ x1, x2, x3, x4, label });
  }
  return data;
}

function normalize(data) {
  const keys = ["x1", "x2", "x3", "x4"];
  const stats = {};
  keys.forEach(k => {
    const vals = data.map(d => d[k]);
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    const std = Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length) || 1;
    stats[k] = { mean, std };
  });
  return data.map(d => {
    const norm = { label: d.label };
    keys.forEach(k => norm[k] = (d[k] - stats[k].mean) / stats[k].std);
    return norm;
  });
}

function trainLogisticRegression(trainData, epochs = 100, lr = 0.1) {
  let w = [0, 0, 0, 0], b = 0;
  const history = [];
  for (let e = 0; e < epochs; e++) {
    let loss = 0, gw = [0, 0, 0, 0], gb = 0;
    trainData.forEach(({ x1, x2, x3, x4, label }) => {
      const z = w[0]*x1 + w[1]*x2 + w[2]*x3 + w[3]*x4 + b;
      const p = sigmoid(z);
      const err = p - label;
      loss += -(label * Math.log(p + 1e-9) + (1 - label) * Math.log(1 - p + 1e-9));
      gw[0] += err * x1; gw[1] += err * x2; gw[2] += err * x3; gw[3] += err * x4;
      gb += err;
    });
    const n = trainData.length;
    w = w.map((wi, i) => wi - lr * gw[i] / n);
    b -= lr * gb / n;
    if (e % 5 === 0) history.push({ epoch: e, loss: loss / n, accuracy: getAccuracy(trainData, w, b) });
  }
  return { w, b, history };
}

function getAccuracy(data, w, b) {
  let correct = 0;
  data.forEach(({ x1, x2, x3, x4, label }) => {
    const z = w[0]*x1 + w[1]*x2 + w[2]*x3 + w[3]*x4 + b;
    if (Math.round(sigmoid(z)) === label) correct++;
  });
  return correct / data.length;
}

function predict(sample, w, b) {
  const z = w[0]*sample.x1 + w[1]*sample.x2 + w[2]*sample.x3 + w[3]*sample.x4 + b;
  return sigmoid(z);
}

function getMetrics(data, w, b, threshold = 0.5) {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  data.forEach(d => {
    const p = predict(d, w, b) >= threshold ? 1 : 0;
    if (p === 1 && d.label === 1) tp++;
    else if (p === 1 && d.label === 0) fp++;
    else if (p === 0 && d.label === 0) tn++;
    else fn++;
  });
  const precision = tp / (tp + fp + 1e-9);
  const recall = tp / (tp + fn + 1e-9);
  const f1 = 2 * precision * recall / (precision + recall + 1e-9);
  const accuracy = (tp + tn) / data.length;
  return { tp, fp, tn, fn, precision, recall, f1, accuracy };
}

function getRocCurve(data, w, b) {
  const thresholds = Array.from({ length: 51 }, (_, i) => i / 50);
  return thresholds.map(t => {
    const { tp, fp, tn, fn } = getMetrics(data, w, b, t);
    const tpr = tp / (tp + fn + 1e-9);
    const fpr = fp / (fp + tn + 1e-9);
    return { fpr: +fpr.toFixed(3), tpr: +tpr.toFixed(3), threshold: t };
  }).sort((a, b) => a.fpr - b.fpr);
}

function auc(roc) {
  let a = 0;
  for (let i = 1; i < roc.length; i++) a += (roc[i].fpr - roc[i-1].fpr) * (roc[i].tpr + roc[i-1].tpr) / 2;
  return Math.abs(a);
}

// ── Color Palette ────────────────────────────────────────────────────────────
const C = {
  bg: "#080c14",
  surface: "#0d1424",
  card: "#111927",
  border: "#1e2d42",
  accent: "#00d4ff",
  accent2: "#00ff9d",
  accent3: "#ff6b6b",
  accent4: "#ffd166",
  text: "#e8f4fd",
  muted: "#4a6580",
  dim: "#2a3f55",
};

// ── Components ───────────────────────────────────────────────────────────────
const Card = ({ children, style = {}, glow }) => (
  <div style={{
    background: C.card,
    border: `1px solid ${C.border}`,
    borderRadius: "16px",
    padding: "24px",
    position: "relative",
    overflow: "hidden",
    boxShadow: glow ? `0 0 30px ${glow}18` : "0 4px 24px #00000040",
    ...style,
  }}>{children}</div>
);

const Pill = ({ children, color = C.accent }) => (
  <span style={{
    background: color + "18",
    border: `1px solid ${color}40`,
    color,
    borderRadius: "99px",
    padding: "3px 12px",
    fontSize: "11px",
    fontWeight: "700",
    letterSpacing: "0.5px",
    textTransform: "uppercase",
  }}>{children}</span>
);

const MetricBox = ({ label, value, sub, color = C.accent, icon }) => (
  <Card glow={color} style={{ flex: 1, minWidth: "140px" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div>
        <div style={{ fontSize: "11px", color: C.muted, letterSpacing: "1.5px", textTransform: "uppercase", marginBottom: "10px" }}>{label}</div>
        <div style={{ fontSize: "32px", fontWeight: "800", color, fontFamily: "'Courier New', monospace", lineHeight: 1 }}>{value}</div>
        {sub && <div style={{ fontSize: "12px", color: C.muted, marginTop: "6px" }}>{sub}</div>}
      </div>
      <span style={{ fontSize: "22px", opacity: 0.6 }}>{icon}</span>
    </div>
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "3px", background: color, opacity: 0.4, borderRadius: "0 0 16px 16px" }} />
  </Card>
);

const SectionLabel = ({ children }) => (
  <div style={{ fontSize: "10px", color: C.muted, letterSpacing: "2.5px", textTransform: "uppercase", marginBottom: "16px", display: "flex", alignItems: "center", gap: "8px" }}>
    <div style={{ width: "18px", height: "1px", background: C.accent }} />
    {children}
    <div style={{ flex: 1, height: "1px", background: C.border }} />
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: "10px", padding: "10px 14px", fontSize: "12px", color: C.text }}>
      <div style={{ color: C.muted, marginBottom: "4px" }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color }}>{p.name}: <strong>{typeof p.value === "number" ? p.value.toFixed(4) : p.value}</strong></div>
      ))}
    </div>
  );
};

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [model, setModel] = useState(null);
  const [trainHistory, setTrainHistory] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [roc, setRoc] = useState([]);
  const [aucScore, setAucScore] = useState(0);
  const [scatterData, setScatterData] = useState({ pos: [], neg: [] });
  const [threshold, setThreshold] = useState(0.5);
  const [training, setTraining] = useState(false);
  const [trained, setTrained] = useState(false);
  const [epochs, setEpochs] = useState(150);
  const [lr, setLr] = useState(0.1);
  const [trainSize, setTrainSize] = useState(160);
  const [activeTab, setActiveTab] = useState("overview");
  const [prediction, setPrediction] = useState(null);
  const [predInput, setPredInput] = useState({ x1: 0.5, x2: 0.8, x3: 0.3, x4: -0.2 });
  const [confMetrics, setConfMetrics] = useState(null);

  const allData = useRef(null);
  const testData = useRef(null);

  const runTraining = useCallback(() => {
    setTraining(true);
    setTimeout(() => {
      const raw = generateDataset(250);
      const norm = normalize(raw);
      allData.current = norm;
      const train = norm.slice(0, trainSize);
      const test = norm.slice(trainSize);
      testData.current = test;

      const { w, b, history } = trainLogisticRegression(train, epochs, lr);
      const rocData = getRocCurve(test, w, b);
      const aucVal = auc(rocData);
      const m = getMetrics(test, w, b, threshold);

      const pos = test.filter(d => d.label === 1).map(d => ({ x: d.x1, y: d.x2 }));
      const neg = test.filter(d => d.label === 0).map(d => ({ x: d.x1, y: d.x2 }));

      setModel({ w, b });
      setTrainHistory(history);
      setRoc(rocData);
      setAucScore(aucVal);
      setMetrics(m);
      setScatterData({ pos, neg });
      setConfMetrics(m);
      setTrained(true);
      setTraining(false);
    }, 50);
  }, [epochs, lr, trainSize, threshold]);

  useEffect(() => { runTraining(); }, []);

  useEffect(() => {
    if (model && testData.current) {
      const m = getMetrics(testData.current, model.w, model.b, threshold);
      setMetrics(m);
      setConfMetrics(m);
    }
  }, [threshold, model]);

  const handlePredict = () => {
    if (!model) return;
    const prob = predict(predInput, model.w, model.b);
    setPrediction(prob);
  };

  const tabs = [
    { id: "overview", label: "Overview", icon: "⬡" },
    { id: "training", label: "Training", icon: "◈" },
    { id: "evaluation", label: "Evaluation", icon: "◎" },
    { id: "predict", label: "Predict", icon: "▶" },
  ];

  const featNames = ["Feature 1", "Feature 2", "Feature 3", "Feature 4"];
  const weightData = model ? model.w.map((wi, i) => ({ name: `F${i+1}`, weight: +wi.toFixed(4), abs: Math.abs(wi) })) : [];

  return (
    <div style={{
      minHeight: "100vh",
      background: C.bg,
      color: C.text,
      fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Background grid */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 0,
        backgroundImage: `linear-gradient(${C.dim}18 1px, transparent 1px), linear-gradient(90deg, ${C.dim}18 1px, transparent 1px)`,
        backgroundSize: "40px 40px",
        pointerEvents: "none",
      }} />
      {/* Glow blobs */}
      <div style={{ position: "fixed", top: "-20%", right: "-10%", width: "500px", height: "500px", borderRadius: "50%", background: `radial-gradient(circle, ${C.accent}08 0%, transparent 70%)`, pointerEvents: "none", zIndex: 0 }} />
      <div style={{ position: "fixed", bottom: "-20%", left: "-10%", width: "500px", height: "500px", borderRadius: "50%", background: `radial-gradient(circle, ${C.accent2}06 0%, transparent 70%)`, pointerEvents: "none", zIndex: 0 }} />

      <div style={{ position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{
          borderBottom: `1px solid ${C.border}`,
          padding: "0 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: "64px",
          background: C.surface + "cc",
          backdropFilter: "blur(12px)",
          position: "sticky", top: 0, zIndex: 100,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <div style={{
              width: "36px", height: "36px", borderRadius: "10px",
              background: `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "16px", fontWeight: "900", color: C.bg,
            }}>σ</div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: "700", color: C.text, letterSpacing: "-0.3px" }}>LogReg Studio</div>
              <div style={{ fontSize: "10px", color: C.muted, letterSpacing: "1.5px" }}>LOGISTIC REGRESSION DASHBOARD</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            {trained && <Pill color={C.accent2}>● TRAINED</Pill>}
            <button onClick={runTraining} disabled={training} style={{
              background: training ? C.dim : `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
              border: "none", borderRadius: "10px", padding: "8px 20px",
              color: C.bg, fontSize: "12px", fontWeight: "700",
              cursor: training ? "not-allowed" : "pointer",
              letterSpacing: "0.5px", fontFamily: "inherit",
              boxShadow: training ? "none" : `0 4px 20px ${C.accent}40`,
            }}>
              {training ? "TRAINING..." : "↺ RETRAIN"}
            </button>
          </div>
        </div>

        {/* Nav Tabs */}
        <div style={{ display: "flex", gap: "0", borderBottom: `1px solid ${C.border}`, padding: "0 32px", background: C.surface + "88" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
              background: "none", border: "none", padding: "14px 20px",
              color: activeTab === t.id ? C.accent : C.muted,
              fontSize: "12px", fontWeight: "600", cursor: "pointer",
              fontFamily: "inherit", letterSpacing: "0.5px",
              borderBottom: `2px solid ${activeTab === t.id ? C.accent : "transparent"}`,
              transition: "all 0.2s",
              display: "flex", alignItems: "center", gap: "8px",
            }}>{t.icon} {t.label.toUpperCase()}</button>
          ))}
        </div>

        <div style={{ padding: "28px 32px", maxWidth: "1400px", margin: "0 auto" }}>

          {/* ── OVERVIEW TAB ── */}
          {activeTab === "overview" && metrics && (
            <div>
              <div style={{ display: "flex", gap: "16px", marginBottom: "24px", flexWrap: "wrap" }}>
                <MetricBox label="Accuracy" value={(metrics.accuracy * 100).toFixed(1) + "%"} sub="Test set" color={C.accent} icon="◎" />
                <MetricBox label="Precision" value={(metrics.precision * 100).toFixed(1) + "%"} sub="Positive class" color={C.accent2} icon="◈" />
                <MetricBox label="Recall" value={(metrics.recall * 100).toFixed(1) + "%"} sub="Sensitivity" color={C.accent4} icon="⬡" />
                <MetricBox label="F1 Score" value={(metrics.f1 * 100).toFixed(1) + "%"} sub="Harmonic mean" color="#a78bfa" icon="▲" />
                <MetricBox label="AUC-ROC" value={aucScore.toFixed(3)} sub="Area under curve" color={C.accent3} icon="◐" />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                {/* Scatter Plot */}
                <Card>
                  <SectionLabel>Decision Boundary (x1 vs x2)</SectionLabel>
                  <ResponsiveContainer width="100%" height={260}>
                    <ScatterChart margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                      <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                      <XAxis dataKey="x" name="Feature 1" tick={{ fill: C.muted, fontSize: 10 }} />
                      <YAxis dataKey="y" name="Feature 2" tick={{ fill: C.muted, fontSize: 10 }} />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} content={<CustomTooltip />} />
                      <Scatter name="Positive (1)" data={scatterData.pos} fill={C.accent2} opacity={0.8} r={4} />
                      <Scatter name="Negative (0)" data={scatterData.neg} fill={C.accent3} opacity={0.8} r={4} />
                    </ScatterChart>
                  </ResponsiveContainer>
                  <div style={{ display: "flex", gap: "16px", marginTop: "8px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "11px", color: C.muted }}>
                      <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: C.accent2 }} /> Class 1
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "11px", color: C.muted }}>
                      <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: C.accent3 }} /> Class 0
                    </div>
                  </div>
                </Card>

                {/* ROC Curve */}
                <Card>
                  <SectionLabel>ROC Curve</SectionLabel>
                  <div style={{ fontSize: "12px", color: C.accent, marginBottom: "10px" }}>AUC = <strong>{aucScore.toFixed(4)}</strong></div>
                  <ResponsiveContainer width="100%" height={240}>
                    <AreaChart data={roc} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                      <defs>
                        <linearGradient id="rocGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={C.accent} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={C.accent} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                      <XAxis dataKey="fpr" name="FPR" tick={{ fill: C.muted, fontSize: 10 }} label={{ value: "False Positive Rate", position: "insideBottom", offset: -2, fill: C.muted, fontSize: 10 }} />
                      <YAxis tick={{ fill: C.muted, fontSize: 10 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="tpr" name="TPR" stroke={C.accent} fill="url(#rocGrad)" strokeWidth={2} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </Card>

                {/* Feature Weights */}
                <Card>
                  <SectionLabel>Feature Weights (Coefficients)</SectionLabel>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={weightData} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                      <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fill: C.muted, fontSize: 11 }} />
                      <YAxis tick={{ fill: C.muted, fontSize: 10 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="weight" name="Weight" radius={[6, 6, 0, 0]}>
                        {weightData.map((entry, i) => (
                          <Cell key={i} fill={entry.weight >= 0 ? C.accent2 : C.accent3} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                  {model && (
                    <div style={{ marginTop: "12px", fontSize: "11px", color: C.muted }}>
                      Bias (b) = <span style={{ color: C.accent }}>{model.b.toFixed(4)}</span>
                    </div>
                  )}
                </Card>

                {/* Confusion Matrix */}
                <Card>
                  <SectionLabel>Confusion Matrix</SectionLabel>
                  {confMetrics && (
                    <div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", maxWidth: "280px", margin: "0 auto" }}>
                        {[
                          { label: "True Positive", val: confMetrics.tp, color: C.accent2 },
                          { label: "False Positive", val: confMetrics.fp, color: C.accent3 },
                          { label: "False Negative", val: confMetrics.fn, color: C.accent3 },
                          { label: "True Negative", val: confMetrics.tn, color: C.accent2 },
                        ].map((cell, i) => (
                          <div key={i} style={{
                            background: cell.color + "14",
                            border: `1px solid ${cell.color}40`,
                            borderRadius: "12px",
                            padding: "16px",
                            textAlign: "center",
                          }}>
                            <div style={{ fontSize: "28px", fontWeight: "800", color: cell.color }}>{cell.val}</div>
                            <div style={{ fontSize: "10px", color: C.muted, marginTop: "4px" }}>{cell.label}</div>
                          </div>
                        ))}
                      </div>
                      <div style={{ marginTop: "16px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                          <span style={{ fontSize: "11px", color: C.muted, width: "80px" }}>Threshold</span>
                          <input type="range" min="0.1" max="0.9" step="0.05" value={threshold}
                            onChange={e => setThreshold(+e.target.value)}
                            style={{ flex: 1, accentColor: C.accent }} />
                          <span style={{ fontSize: "12px", color: C.accent, width: "36px", textAlign: "right" }}>{threshold.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>
          )}

          {/* ── TRAINING TAB ── */}
          {activeTab === "training" && (
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: "20px", alignItems: "start" }}>
                {/* Hyperparameters */}
                <Card>
                  <SectionLabel>Hyperparameters</SectionLabel>
                  <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                    {[
                      { label: "Learning Rate", key: "lr", val: lr, set: setLr, min: 0.001, max: 1, step: 0.001, display: lr.toFixed(3) },
                      { label: "Epochs", key: "epochs", val: epochs, set: setEpochs, min: 20, max: 500, step: 10, display: epochs },
                      { label: "Train Size", key: "trainSize", val: trainSize, set: setTrainSize, min: 50, max: 220, step: 10, display: trainSize },
                    ].map(p => (
                      <div key={p.key}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                          <span style={{ fontSize: "11px", color: C.muted, letterSpacing: "1px" }}>{p.label.toUpperCase()}</span>
                          <span style={{ fontSize: "13px", color: C.accent, fontWeight: "700" }}>{p.display}</span>
                        </div>
                        <input type="range" min={p.min} max={p.max} step={p.step} value={p.val}
                          onChange={e => p.set(+e.target.value)}
                          style={{ width: "100%", accentColor: C.accent }} />
                        <div style={{ display: "flex", justifyContent: "space-between", fontSize: "10px", color: C.dim, marginTop: "3px" }}>
                          <span>{p.min}</span><span>{p.max}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button onClick={runTraining} disabled={training} style={{
                    marginTop: "24px", width: "100%",
                    background: `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
                    border: "none", borderRadius: "10px", padding: "12px",
                    color: C.bg, fontSize: "13px", fontWeight: "700",
                    cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.5px",
                    boxShadow: `0 4px 20px ${C.accent}30`,
                  }}>▶ RUN TRAINING</button>

                  {model && (
                    <div style={{ marginTop: "20px", padding: "14px", background: C.surface, borderRadius: "10px", border: `1px solid ${C.border}` }}>
                      <div style={{ fontSize: "10px", color: C.muted, marginBottom: "8px", letterSpacing: "1px" }}>MODEL WEIGHTS</div>
                      {model.w.map((wi, i) => (
                        <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", padding: "3px 0", borderBottom: `1px solid ${C.border}` }}>
                          <span style={{ color: C.muted }}>w{i + 1}</span>
                          <span style={{ color: wi >= 0 ? C.accent2 : C.accent3 }}>{wi >= 0 ? "+" : ""}{wi.toFixed(4)}</span>
                        </div>
                      ))}
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", paddingTop: "4px" }}>
                        <span style={{ color: C.muted }}>bias</span>
                        <span style={{ color: C.accent4 }}>{model.b >= 0 ? "+" : ""}{model.b.toFixed(4)}</span>
                      </div>
                    </div>
                  )}
                </Card>

                {/* Training Charts */}
                <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                  <Card>
                    <SectionLabel>Loss Curve (Cross-Entropy)</SectionLabel>
                    <ResponsiveContainer width="100%" height={220}>
                      <AreaChart data={trainHistory} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                        <defs>
                          <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={C.accent3} stopOpacity={0.4} />
                            <stop offset="95%" stopColor={C.accent3} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                        <XAxis dataKey="epoch" tick={{ fill: C.muted, fontSize: 10 }} label={{ value: "Epoch", position: "insideBottom", offset: -2, fill: C.muted, fontSize: 10 }} />
                        <YAxis tick={{ fill: C.muted, fontSize: 10 }} />
                        <Tooltip content={<CustomTooltip />} />
                        <Area type="monotone" dataKey="loss" name="Loss" stroke={C.accent3} fill="url(#lossGrad)" strokeWidth={2.5} dot={false} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Card>
                  <Card>
                    <SectionLabel>Accuracy Curve</SectionLabel>
                    <ResponsiveContainer width="100%" height={220}>
                      <AreaChart data={trainHistory} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                        <defs>
                          <linearGradient id="accGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={C.accent2} stopOpacity={0.4} />
                            <stop offset="95%" stopColor={C.accent2} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                        <XAxis dataKey="epoch" tick={{ fill: C.muted, fontSize: 10 }} />
                        <YAxis domain={[0, 1]} tick={{ fill: C.muted, fontSize: 10 }} />
                        <Tooltip content={<CustomTooltip />} />
                        <Area type="monotone" dataKey="accuracy" name="Accuracy" stroke={C.accent2} fill="url(#accGrad)" strokeWidth={2.5} dot={false} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Card>
                </div>
              </div>
            </div>
          )}

          {/* ── EVALUATION TAB ── */}
          {activeTab === "evaluation" && metrics && (
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: "16px", marginBottom: "24px" }}>
                <MetricBox label="Accuracy" value={(metrics.accuracy * 100).toFixed(2) + "%"} color={C.accent} icon="◎" />
                <MetricBox label="Precision" value={(metrics.precision * 100).toFixed(2) + "%"} color={C.accent2} icon="◈" />
                <MetricBox label="Recall" value={(metrics.recall * 100).toFixed(2) + "%"} color={C.accent4} icon="⬡" />
                <MetricBox label="F1 Score" value={(metrics.f1 * 100).toFixed(2) + "%"} color="#a78bfa" icon="▲" />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                <Card>
                  <SectionLabel>Precision-Recall Trade-off</SectionLabel>
                  <div style={{ marginBottom: "12px", display: "flex", alignItems: "center", gap: "10px" }}>
                    <span style={{ fontSize: "11px", color: C.muted }}>THRESHOLD</span>
                    <input type="range" min="0.05" max="0.95" step="0.05" value={threshold}
                      onChange={e => setThreshold(+e.target.value)}
                      style={{ flex: 1, accentColor: C.accent }} />
                    <span style={{ fontSize: "13px", color: C.accent, fontWeight: "700", width: "40px" }}>{threshold.toFixed(2)}</span>
                  </div>
                  <div style={{ display: "flex", gap: "12px" }}>
                    {[
                      { label: "Precision", val: metrics.precision, color: C.accent2 },
                      { label: "Recall", val: metrics.recall, color: C.accent4 },
                      { label: "F1", val: metrics.f1, color: "#a78bfa" },
                    ].map(m => (
                      <div key={m.label} style={{ flex: 1, textAlign: "center", padding: "16px", background: m.color + "12", borderRadius: "12px", border: `1px solid ${m.color}30` }}>
                        <div style={{ fontSize: "22px", fontWeight: "800", color: m.color }}>{(m.val * 100).toFixed(1)}%</div>
                        <div style={{ fontSize: "10px", color: C.muted, marginTop: "4px" }}>{m.label}</div>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card>
                  <SectionLabel>Classification Report</SectionLabel>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                    <thead>
                      <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                        {["Class", "Precision", "Recall", "F1", "Support"].map(h => (
                          <th key={h} style={{ color: C.muted, padding: "8px 6px", textAlign: "left", fontWeight: "600", fontSize: "10px", letterSpacing: "1px" }}>{h.toUpperCase()}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { cls: "0 (Neg)", p: metrics.tn / (metrics.tn + metrics.fn + 1e-9), r: metrics.tn / (metrics.tn + metrics.fp + 1e-9), sup: metrics.tn + metrics.fp },
                        { cls: "1 (Pos)", p: metrics.precision, r: metrics.recall, sup: metrics.tp + metrics.fn },
                      ].map((row, i) => {
                        const f1r = 2 * row.p * row.r / (row.p + row.r + 1e-9);
                        return (
                          <tr key={i} style={{ borderBottom: `1px solid ${C.border}20` }}>
                            <td style={{ padding: "10px 6px", color: i === 1 ? C.accent2 : C.accent3, fontWeight: "600" }}>{row.cls}</td>
                            <td style={{ padding: "10px 6px", color: C.text }}>{(row.p * 100).toFixed(1)}%</td>
                            <td style={{ padding: "10px 6px", color: C.text }}>{(row.r * 100).toFixed(1)}%</td>
                            <td style={{ padding: "10px 6px", color: C.text }}>{(f1r * 100).toFixed(1)}%</td>
                            <td style={{ padding: "10px 6px", color: C.muted }}>{row.sup}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <div style={{ marginTop: "14px", padding: "12px", background: C.surface, borderRadius: "10px", fontSize: "12px", display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: C.muted }}>Overall Accuracy</span>
                    <span style={{ color: C.accent, fontWeight: "700" }}>{(metrics.accuracy * 100).toFixed(2)}%</span>
                  </div>
                </Card>

                <Card style={{ gridColumn: "span 2" }}>
                  <SectionLabel>ROC Curve Analysis</SectionLabel>
                  <div style={{ display: "flex", gap: "24px", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: "11px", color: C.muted, marginBottom: "4px" }}>AUC SCORE</div>
                      <div style={{ fontSize: "40px", fontWeight: "800", color: C.accent }}>{aucScore.toFixed(4)}</div>
                      <div style={{ fontSize: "11px", color: aucScore > 0.9 ? C.accent2 : aucScore > 0.8 ? C.accent4 : C.accent3, marginTop: "4px" }}>
                        {aucScore > 0.9 ? "● Excellent" : aucScore > 0.8 ? "● Good" : "● Fair"}
                      </div>
                    </div>
                    <div style={{ flex: 1 }}>
                      <ResponsiveContainer width="100%" height={200}>
                        <AreaChart data={roc} margin={{ top: 5, right: 10, bottom: 20, left: 0 }}>
                          <defs>
                            <linearGradient id="rocGrad2" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor={C.accent} stopOpacity={0.35} />
                              <stop offset="95%" stopColor={C.accent} stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                          <XAxis dataKey="fpr" tick={{ fill: C.muted, fontSize: 10 }} label={{ value: "FPR", position: "insideBottom", offset: -10, fill: C.muted, fontSize: 10 }} />
                          <YAxis tick={{ fill: C.muted, fontSize: 10 }} />
                          <Tooltip content={<CustomTooltip />} />
                          <Area type="monotone" dataKey="tpr" name="TPR" stroke={C.accent} fill="url(#rocGrad2)" strokeWidth={2.5} dot={false} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          )}

          {/* ── PREDICT TAB ── */}
          {activeTab === "predict" && (
            <div style={{ display: "grid", gridTemplateColumns: "380px 1fr", gap: "20px", alignItems: "start" }}>
              <Card>
                <SectionLabel>Input Features</SectionLabel>
                {["x1", "x2", "x3", "x4"].map((k, i) => (
                  <div key={k} style={{ marginBottom: "18px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                      <span style={{ fontSize: "11px", color: C.muted, letterSpacing: "1px" }}>FEATURE {i + 1} ({k.toUpperCase()})</span>
                      <span style={{ fontSize: "13px", color: C.accent, fontWeight: "700" }}>{predInput[k].toFixed(2)}</span>
                    </div>
                    <input type="range" min="-3" max="3" step="0.1" value={predInput[k]}
                      onChange={e => setPredInput(prev => ({ ...prev, [k]: +e.target.value }))}
                      style={{ width: "100%", accentColor: C.accent }} />
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: "10px", color: C.dim, marginTop: "2px" }}>
                      <span>-3.0</span><span>3.0</span>
                    </div>
                  </div>
                ))}
                <button onClick={handlePredict} style={{
                  width: "100%", marginTop: "8px",
                  background: `linear-gradient(135deg, ${C.accent}, ${C.accent2})`,
                  border: "none", borderRadius: "10px", padding: "14px",
                  color: C.bg, fontSize: "13px", fontWeight: "700",
                  cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.5px",
                  boxShadow: `0 4px 20px ${C.accent}30`,
                }}>▶ PREDICT</button>
              </Card>

              <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                {prediction !== null && (
                  <Card glow={prediction >= threshold ? C.accent2 : C.accent3}>
                    <SectionLabel>Prediction Result</SectionLabel>
                    <div style={{ display: "flex", gap: "32px", alignItems: "center" }}>
                      <div style={{ textAlign: "center" }}>
                        <div style={{ fontSize: "11px", color: C.muted, marginBottom: "8px", letterSpacing: "1.5px" }}>PROBABILITY</div>
                        <div style={{ fontSize: "56px", fontWeight: "900", color: prediction >= threshold ? C.accent2 : C.accent3, lineHeight: 1 }}>
                          {(prediction * 100).toFixed(1)}%
                        </div>
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ marginBottom: "16px" }}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                            <span style={{ fontSize: "12px", color: C.muted }}>Confidence</span>
                            <span style={{ fontSize: "12px", color: C.accent }}>{(prediction * 100).toFixed(2)}%</span>
                          </div>
                          <div style={{ height: "10px", borderRadius: "99px", background: C.border }}>
                            <div style={{ height: "100%", borderRadius: "99px", width: `${prediction * 100}%`, background: prediction >= threshold ? `linear-gradient(90deg, ${C.accent2}, ${C.accent})` : `linear-gradient(90deg, ${C.accent3}, ${C.accent4})`, transition: "width 0.5s ease" }} />
                          </div>
                        </div>
                        <div style={{
                          padding: "16px 20px",
                          background: (prediction >= threshold ? C.accent2 : C.accent3) + "14",
                          border: `1px solid ${(prediction >= threshold ? C.accent2 : C.accent3)}40`,
                          borderRadius: "12px",
                          textAlign: "center",
                        }}>
                          <div style={{ fontSize: "11px", color: C.muted, marginBottom: "4px" }}>PREDICTED CLASS</div>
                          <div style={{ fontSize: "28px", fontWeight: "800", color: prediction >= threshold ? C.accent2 : C.accent3 }}>
                            {prediction >= threshold ? "Class 1 (Positive)" : "Class 0 (Negative)"}
                          </div>
                          <div style={{ fontSize: "11px", color: C.muted, marginTop: "4px" }}>at threshold {threshold.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  </Card>
                )}

                <Card>
                  <SectionLabel>Sigmoid Function Output</SectionLabel>
                  {model && (() => {
                    const z = model.w[0]*predInput.x1 + model.w[1]*predInput.x2 + model.w[2]*predInput.x3 + model.w[3]*predInput.x4 + model.b;
                    const sigData = Array.from({ length: 61 }, (_, i) => {
                      const zv = -6 + i * 0.2;
                      return { z: +zv.toFixed(1), sigma: +sigmoid(zv).toFixed(4) };
                    });
                    return (
                      <div>
                        <div style={{ fontSize: "12px", color: C.muted, marginBottom: "10px" }}>
                          z = {z.toFixed(4)} → σ(z) = <span style={{ color: C.accent, fontWeight: "700" }}>{sigmoid(z).toFixed(4)}</span>
                        </div>
                        <ResponsiveContainer width="100%" height={200}>
                          <LineChart data={sigData} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                            <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                            <XAxis dataKey="z" tick={{ fill: C.muted, fontSize: 10 }} />
                            <YAxis domain={[0, 1]} tick={{ fill: C.muted, fontSize: 10 }} />
                            <Tooltip content={<CustomTooltip />} />
                            <Line type="monotone" dataKey="sigma" name="σ(z)" stroke={C.accent4} strokeWidth={2.5} dot={false} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    );
                  })()}
                </Card>
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        input[type=range] { height: 4px; cursor: pointer; }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: ${C.bg}; } ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 3px; }
      `}</style>
    </div>
  );
}
