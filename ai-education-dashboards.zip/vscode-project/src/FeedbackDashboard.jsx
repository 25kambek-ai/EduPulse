import { useState, useEffect, useRef } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, RadialBarChart, RadialBar } from "recharts";

// ── Sample Data ──────────────────────────────────────────────────────────────
const INITIAL_FEEDBACK = [
  { id: 1, type: "positive", author: "Priya M.", role: "Student", rating: 5, text: "The explanations are crystal clear and the examples really help me understand difficult concepts. Best teacher I've had!", category: "Teaching Clarity", date: "2025-04-18", avatar: "PM" },
  { id: 2, type: "negative", author: "Rahul S.", role: "Student", rating: 2, text: "The pace is way too fast. We rush through important topics and I often leave class confused. Needs to slow down.", category: "Pacing", date: "2025-04-17", avatar: "RS" },
  { id: 3, type: "positive", author: "Anita K.", role: "Student", rating: 5, text: "Very engaging sessions! Always uses real-world examples and makes even complex topics feel approachable.", category: "Engagement", date: "2025-04-17", avatar: "AK" },
  { id: 4, type: "negative", author: "Dev P.", role: "Student", rating: 1, text: "Questions are dismissed and the attitude is discouraging. Students feel afraid to participate in class.", category: "Behavior", date: "2025-04-16", avatar: "DP" },
  { id: 5, type: "positive", author: "Meera T.", role: "Student", rating: 4, text: "Great communication style. Always responds to emails promptly and genuinely cares about student progress.", category: "Communication", date: "2025-04-16", avatar: "MT" },
  { id: 6, type: "negative", author: "Arjun V.", role: "Student", rating: 2, text: "Course is extremely difficult with very little support. Office hours are rarely accessible and emails often go unanswered.", category: "Support", date: "2025-04-15", avatar: "AV" },
  { id: 7, type: "positive", author: "Sneha R.", role: "Student", rating: 5, text: "Absolutely knowledgeable and passionate! Makes every lecture feel exciting and relevant to our future careers.", category: "Engagement", date: "2025-04-15", avatar: "SR" },
  { id: 8, type: "negative", author: "Kiran B.", role: "Student", rating: 2, text: "Assignments feel completely disconnected from what we cover in lectures. More alignment between class and homework is needed.", category: "Course Design", date: "2025-04-14", avatar: "KB" },
  { id: 9, type: "positive", author: "Nisha C.", role: "Student", rating: 4, text: "Structured and well-prepared lessons every time. Slides are clear and the learning objectives are always communicated upfront.", category: "Teaching Clarity", date: "2025-04-14", avatar: "NC" },
  { id: 10, type: "negative", author: "Rohan D.", role: "Student", rating: 3, text: "Lectures are monotonous. It's hard to stay engaged for long periods. More interactive activities would greatly help.", category: "Engagement", date: "2025-04-13", avatar: "RD" },
  { id: 11, type: "positive", author: "Pooja L.", role: "Student", rating: 5, text: "Always willing to help after class. The extra time spent with struggling students really shows dedication.", category: "Support", date: "2025-04-13", avatar: "PL" },
  { id: 12, type: "positive", author: "Vikram N.", role: "Student", rating: 4, text: "Tests and quizzes are fair and well-aligned with course material. Assessment design is excellent.", category: "Course Design", date: "2025-04-12", avatar: "VN" },
];

const CATEGORIES = ["All", "Teaching Clarity", "Engagement", "Communication", "Pacing", "Behavior", "Support", "Course Design"];
const RATINGS = ["All", "5★", "4★", "3★", "2★", "1★"];

const trendData = [
  { month: "Nov", positive: 12, negative: 8 },
  { month: "Dec", positive: 15, negative: 6 },
  { month: "Jan", positive: 18, negative: 9 },
  { month: "Feb", positive: 22, negative: 7 },
  { month: "Mar", positive: 19, negative: 11 },
  { month: "Apr", positive: 25, negative: 6 },
];

const categoryData = [
  { name: "Teaching", positive: 8, negative: 3 },
  { name: "Engagement", positive: 7, negative: 4 },
  { name: "Support", positive: 5, negative: 5 },
  { name: "Pacing", positive: 2, negative: 6 },
  { name: "Behavior", positive: 3, negative: 4 },
  { name: "Course", positive: 6, negative: 3 },
];

// ── Helpers ──────────────────────────────────────────────────────────────────
const P = "#10b981";   // positive green
const N = "#f43f5e";   // negative rose
const BG = "#f8f6f0";  // warm cream
const SURFACE = "#ffffff";
const BORDER = "#e8e2d9";
const TEXT = "#1c1a17";
const MUTED = "#8b7e6e";
const ACCENT = "#d97706"; // amber accent

const avatarColor = (type) => type === "positive"
  ? { bg: "#d1fae5", color: "#065f46" }
  : { bg: "#ffe4e6", color: "#9f1239" };

const StarRating = ({ rating, size = 13 }) => (
  <span>{Array.from({ length: 5 }, (_, i) => (
    <span key={i} style={{ color: i < rating ? "#f59e0b" : "#d1c9be", fontSize: size }}>★</span>
  ))}</span>
);

const Badge = ({ type }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: "4px",
    background: type === "positive" ? "#d1fae5" : "#ffe4e6",
    color: type === "positive" ? "#065f46" : "#9f1239",
    borderRadius: "99px", padding: "3px 10px", fontSize: "11px", fontWeight: "700",
    letterSpacing: "0.3px",
  }}>
    {type === "positive" ? "▲ Positive" : "▼ Negative"}
  </span>
);

const CategoryTag = ({ cat }) => (
  <span style={{
    background: "#f3ede4", color: MUTED, borderRadius: "6px",
    padding: "2px 9px", fontSize: "11px", fontWeight: "600",
  }}>{cat}</span>
);

// ── Feedback Card ─────────────────────────────────────────────────────────────
const FeedbackCard = ({ item, delay = 0 }) => {
  const ac = avatarColor(item.type);
  return (
    <div style={{
      background: SURFACE,
      border: `1px solid ${BORDER}`,
      borderLeft: `4px solid ${item.type === "positive" ? P : N}`,
      borderRadius: "14px",
      padding: "18px 20px",
      marginBottom: "12px",
      boxShadow: "0 2px 12px #00000008",
      animation: `fadeUp 0.4s ease ${delay}s both`,
      transition: "box-shadow 0.2s, transform 0.2s",
      cursor: "default",
    }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow = "0 6px 24px #00000014"; e.currentTarget.style.transform = "translateY(-1px)"; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow = "0 2px 12px #00000008"; e.currentTarget.style.transform = "translateY(0)"; }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "10px" }}>
        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          <div style={{
            width: "38px", height: "38px", borderRadius: "50%",
            background: ac.bg, color: ac.color,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "12px", fontWeight: "800", letterSpacing: "0.5px", flexShrink: 0,
          }}>{item.avatar}</div>
          <div>
            <div style={{ fontWeight: "700", fontSize: "14px", color: TEXT }}>{item.author}</div>
            <div style={{ fontSize: "11px", color: MUTED }}>{item.role} · {item.date}</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "5px" }}>
          <Badge type={item.type} />
          <StarRating rating={item.rating} />
        </div>
      </div>
      <p style={{ fontSize: "13.5px", color: "#3d3730", lineHeight: "1.7", margin: "0 0 10px 0" }}>"{item.text}"</p>
      <CategoryTag cat={item.category} />
    </div>
  );
};

// ── Stat Card ─────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, sub, icon, color, bg }) => (
  <div style={{
    background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "16px",
    padding: "22px 24px", flex: 1, minWidth: "130px",
    boxShadow: "0 2px 12px #00000006", position: "relative", overflow: "hidden",
  }}>
    <div style={{ position: "absolute", top: "-10px", right: "-10px", fontSize: "56px", opacity: 0.07 }}>{icon}</div>
    <div style={{ fontSize: "11px", color: MUTED, letterSpacing: "1.5px", textTransform: "uppercase", marginBottom: "8px" }}>{label}</div>
    <div style={{ fontSize: "34px", fontWeight: "800", color, lineHeight: 1, fontFamily: "'Georgia', serif" }}>{value}</div>
    {sub && <div style={{ fontSize: "12px", color: MUTED, marginTop: "6px" }}>{sub}</div>}
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "3px", background: color, opacity: 0.25, borderRadius: "0 0 16px 16px" }} />
  </div>
);

// ── Custom Tooltip ────────────────────────────────────────────────────────────
const CT = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "10px", padding: "10px 14px", fontSize: "12px", boxShadow: "0 4px 20px #00000014" }}>
      <div style={{ color: MUTED, marginBottom: "5px", fontWeight: "600" }}>{label}</div>
      {payload.map((p, i) => <div key={i} style={{ color: p.color, fontWeight: "600" }}>{p.name}: {p.value}</div>)}
    </div>
  );
};

// ── Add Feedback Modal ────────────────────────────────────────────────────────
const AddModal = ({ onClose, onAdd }) => {
  const [form, setForm] = useState({ type: "positive", author: "", role: "Student", rating: 5, text: "", category: "Teaching Clarity" });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const submit = () => {
    if (!form.author.trim() || !form.text.trim()) return;
    const initials = form.author.trim().split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
    onAdd({ ...form, id: Date.now(), date: new Date().toISOString().slice(0, 10), avatar: initials });
    onClose();
  };
  const inputStyle = { width: "100%", padding: "10px 14px", border: `1px solid ${BORDER}`, borderRadius: "10px", fontSize: "13px", color: TEXT, background: BG, boxSizing: "border-box", fontFamily: "inherit", outline: "none" };
  return (
    <div style={{ position: "fixed", inset: 0, background: "#00000055", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div style={{ background: SURFACE, borderRadius: "20px", padding: "32px", width: "480px", maxWidth: "95vw", boxShadow: "0 20px 60px #00000030", animation: "fadeUp 0.3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
          <div style={{ fontSize: "18px", fontWeight: "800", color: TEXT, fontFamily: "'Georgia', serif" }}>Add Feedback</div>
          <button onClick={onClose} style={{ background: "#f3ede4", border: "none", borderRadius: "8px", width: "32px", height: "32px", cursor: "pointer", fontSize: "16px", color: MUTED }}>×</button>
        </div>

        <div style={{ display: "flex", gap: "10px", marginBottom: "18px" }}>
          {["positive", "negative"].map(t => (
            <button key={t} onClick={() => set("type", t)} style={{
              flex: 1, padding: "10px", border: `2px solid ${form.type === t ? (t === "positive" ? P : N) : BORDER}`,
              borderRadius: "10px", background: form.type === t ? (t === "positive" ? "#d1fae5" : "#ffe4e6") : BG,
              color: form.type === t ? (t === "positive" ? "#065f46" : "#9f1239") : MUTED,
              fontWeight: "700", cursor: "pointer", fontSize: "13px", fontFamily: "inherit", textTransform: "capitalize",
            }}>{t === "positive" ? "▲ Positive" : "▼ Negative"}</button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", marginBottom: "14px" }}>
          <div>
            <label style={{ fontSize: "11px", color: MUTED, letterSpacing: "1px", display: "block", marginBottom: "6px" }}>STUDENT NAME</label>
            <input style={inputStyle} value={form.author} onChange={e => set("author", e.target.value)} placeholder="e.g. Priya Mehta" />
          </div>
          <div>
            <label style={{ fontSize: "11px", color: MUTED, letterSpacing: "1px", display: "block", marginBottom: "6px" }}>CATEGORY</label>
            <select style={inputStyle} value={form.category} onChange={e => set("category", e.target.value)}>
              {CATEGORIES.filter(c => c !== "All").map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div style={{ marginBottom: "14px" }}>
          <label style={{ fontSize: "11px", color: MUTED, letterSpacing: "1px", display: "block", marginBottom: "6px" }}>RATING</label>
          <div style={{ display: "flex", gap: "8px" }}>
            {[1, 2, 3, 4, 5].map(r => (
              <button key={r} onClick={() => set("rating", r)} style={{
                width: "38px", height: "38px", borderRadius: "8px", border: `1px solid ${BORDER}`,
                background: form.rating >= r ? "#fef3c7" : BG,
                color: form.rating >= r ? "#d97706" : MUTED,
                fontSize: "18px", cursor: "pointer",
              }}>★</button>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: "20px" }}>
          <label style={{ fontSize: "11px", color: MUTED, letterSpacing: "1px", display: "block", marginBottom: "6px" }}>FEEDBACK</label>
          <textarea style={{ ...inputStyle, resize: "vertical", minHeight: "90px", lineHeight: 1.6 }}
            value={form.text} onChange={e => set("text", e.target.value)} placeholder="Write student feedback here..." />
        </div>

        <button onClick={submit} style={{
          width: "100%", padding: "13px",
          background: form.type === "positive" ? `linear-gradient(135deg, #059669, #10b981)` : `linear-gradient(135deg, #e11d48, #f43f5e)`,
          border: "none", borderRadius: "12px", color: "white", fontWeight: "700", fontSize: "14px",
          cursor: "pointer", fontFamily: "inherit", letterSpacing: "0.3px",
          boxShadow: form.type === "positive" ? "0 4px 16px #10b98140" : "0 4px 16px #f43f5e40",
        }}>Submit Feedback</button>
      </div>
    </div>
  );
};

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function FeedbackDashboard() {
  const [feedback, setFeedback] = useState(INITIAL_FEEDBACK);
  const [activePage, setActivePage] = useState("dashboard");
  const [filterType, setFilterType] = useState("all");
  const [filterCat, setFilterCat] = useState("All");
  const [filterRating, setFilterRating] = useState("All");
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [sortBy, setSortBy] = useState("newest");

  const pos = feedback.filter(f => f.type === "positive");
  const neg = feedback.filter(f => f.type === "negative");
  const avgRating = (feedback.reduce((a, b) => a + b.rating, 0) / feedback.length).toFixed(1);
  const posRate = Math.round((pos.length / feedback.length) * 100);

  const filtered = feedback.filter(f => {
    if (filterType !== "all" && f.type !== filterType) return false;
    if (filterCat !== "All" && f.category !== filterCat) return false;
    if (filterRating !== "All" && f.rating !== parseInt(filterRating)) return false;
    if (search && !f.text.toLowerCase().includes(search.toLowerCase()) && !f.author.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }).sort((a, b) => {
    if (sortBy === "newest") return b.id - a.id;
    if (sortBy === "oldest") return a.id - b.id;
    if (sortBy === "highest") return b.rating - a.rating;
    if (sortBy === "lowest") return a.rating - b.rating;
    return 0;
  });

  const pieData = [
    { name: "Positive", value: pos.length, color: P },
    { name: "Negative", value: neg.length, color: N },
  ];

  const catBreakdown = CATEGORIES.filter(c => c !== "All").map(cat => ({
    name: cat.replace(" ", "\n"), cat,
    pos: feedback.filter(f => f.category === cat && f.type === "positive").length,
    neg: feedback.filter(f => f.category === cat && f.type === "negative").length,
  }));

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: "◈" },
    { id: "positive", label: "Positive", icon: "▲" },
    { id: "negative", label: "Negative", icon: "▼" },
    { id: "all", label: "All Feedback", icon: "≡" },
  ];

  const pageFilter = activePage === "positive" ? "positive" : activePage === "negative" ? "negative" : filterType;
  const pageFiltered = feedback.filter(f => {
    const typeMatch = activePage === "dashboard" ? (filterType === "all" || f.type === filterType) : f.type === activePage || activePage === "all";
    if (!typeMatch) return false;
    if (filterCat !== "All" && f.category !== filterCat) return false;
    if (filterRating !== "All" && f.rating !== parseInt(filterRating)) return false;
    if (search && !f.text.toLowerCase().includes(search.toLowerCase()) && !f.author.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }).sort((a, b) => {
    if (sortBy === "newest") return b.id - a.id;
    if (sortBy === "oldest") return a.id - b.id;
    if (sortBy === "highest") return b.rating - a.rating;
    if (sortBy === "lowest") return a.rating - b.rating;
    return 0;
  });

  return (
    <div style={{ minHeight: "100vh", background: BG, fontFamily: "'Georgia', 'Times New Roman', serif", display: "flex" }}>
      {/* Sidebar */}
      <div style={{
        width: "230px", minHeight: "100vh", background: TEXT, flexShrink: 0,
        display: "flex", flexDirection: "column", padding: "0",
        boxShadow: "4px 0 24px #00000020", position: "sticky", top: 0, height: "100vh",
      }}>
        {/* Logo */}
        <div style={{ padding: "28px 24px 20px", borderBottom: "1px solid #2e2b27" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: `linear-gradient(135deg, ${P}, ${ACCENT})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px" }}>⊕</div>
            <div>
              <div style={{ color: "#f8f6f0", fontWeight: "700", fontSize: "14px" }}>FeedbackIQ</div>
              <div style={{ color: "#6b5f52", fontSize: "10px", letterSpacing: "1.5px" }}>ANALYTICS</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ padding: "16px 14px", flex: 1 }}>
          <div style={{ fontSize: "10px", color: "#4a3f35", letterSpacing: "1.5px", padding: "0 10px", marginBottom: "8px" }}>NAVIGATION</div>
          {navItems.map(item => (
            <button key={item.id} onClick={() => setActivePage(item.id)} style={{
              width: "100%", display: "flex", alignItems: "center", gap: "10px",
              padding: "11px 14px", borderRadius: "10px", border: "none",
              background: activePage === item.id ? "#2a2520" : "none",
              color: activePage === item.id ? (item.id === "positive" ? "#6ee7b7" : item.id === "negative" ? "#fda4af" : "#f8f6f0") : "#7a6a5c",
              fontWeight: activePage === item.id ? "700" : "500",
              cursor: "pointer", fontSize: "13px", fontFamily: "inherit",
              marginBottom: "2px", textAlign: "left", transition: "all 0.15s",
              borderLeft: activePage === item.id ? `3px solid ${item.id === "positive" ? P : item.id === "negative" ? N : ACCENT}` : "3px solid transparent",
            }}>
              <span style={{ fontSize: "16px" }}>{item.icon}</span>
              {item.label}
              {item.id !== "dashboard" && (
                <span style={{ marginLeft: "auto", background: "#2a2520", borderRadius: "99px", padding: "1px 8px", fontSize: "11px", color: item.id === "positive" ? "#6ee7b7" : item.id === "negative" ? "#fda4af" : "#f8f6f0" }}>
                  {item.id === "positive" ? pos.length : item.id === "negative" ? neg.length : feedback.length}
                </span>
              )}
            </button>
          ))}

          <div style={{ height: "1px", background: "#2e2b27", margin: "16px 0" }} />
          <div style={{ fontSize: "10px", color: "#4a3f35", letterSpacing: "1.5px", padding: "0 10px", marginBottom: "8px" }}>QUICK STATS</div>

          {[
            { label: "Avg Rating", val: avgRating + " ★", color: "#fbbf24" },
            { label: "Satisfaction", val: posRate + "%", color: "#6ee7b7" },
            { label: "Total Reviews", val: feedback.length, color: "#93c5fd" },
          ].map(s => (
            <div key={s.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 14px", borderRadius: "8px" }}>
              <span style={{ fontSize: "12px", color: "#6b5f52" }}>{s.label}</span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: s.color }}>{s.val}</span>
            </div>
          ))}
        </nav>

        <div style={{ padding: "16px 14px", borderTop: "1px solid #2e2b27" }}>
          <button onClick={() => setShowModal(true)} style={{
            width: "100%", padding: "12px",
            background: `linear-gradient(135deg, ${ACCENT}, #f59e0b)`,
            border: "none", borderRadius: "10px", color: "white",
            fontWeight: "700", fontSize: "13px", cursor: "pointer",
            fontFamily: "inherit", boxShadow: "0 4px 16px #d9770640",
          }}>+ Add Feedback</button>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, overflow: "auto" }}>
        {/* Header */}
        <div style={{ background: SURFACE, borderBottom: `1px solid ${BORDER}`, padding: "20px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 50 }}>
          <div>
            <div style={{ fontSize: "22px", fontWeight: "800", color: TEXT }}>
              {activePage === "dashboard" && "Overview Dashboard"}
              {activePage === "positive" && <span style={{ color: "#059669" }}>▲ Positive Feedback</span>}
              {activePage === "negative" && <span style={{ color: "#e11d48" }}>▼ Negative Feedback</span>}
              {activePage === "all" && "All Feedback"}
            </div>
            <div style={{ fontSize: "12px", color: MUTED, marginTop: "2px" }}>
              {activePage === "dashboard" && "Complete analytics overview"}
              {activePage === "positive" && `${pos.length} positive responses collected`}
              {activePage === "negative" && `${neg.length} concerns to address`}
              {activePage === "all" && `${feedback.length} total feedback entries`}
            </div>
          </div>
          <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search feedback..."
              style={{ padding: "9px 14px", border: `1px solid ${BORDER}`, borderRadius: "10px", fontSize: "13px", color: TEXT, background: BG, outline: "none", width: "200px", fontFamily: "inherit" }} />
            <button onClick={() => setShowModal(true)} style={{
              padding: "9px 20px",
              background: `linear-gradient(135deg, ${ACCENT}, #f59e0b)`,
              border: "none", borderRadius: "10px", color: "white",
              fontWeight: "700", fontSize: "13px", cursor: "pointer", fontFamily: "inherit",
            }}>+ Add</button>
          </div>
        </div>

        <div style={{ padding: "28px 32px" }}>

          {/* ── DASHBOARD PAGE ── */}
          {activePage === "dashboard" && (
            <>
              {/* Stats Row */}
              <div style={{ display: "flex", gap: "16px", marginBottom: "24px", flexWrap: "wrap" }}>
                <StatCard label="Total Feedback" value={feedback.length} sub="All responses" icon="⊕" color={ACCENT} />
                <StatCard label="Positive" value={pos.length} sub={posRate + "% satisfaction"} icon="▲" color={P} />
                <StatCard label="Negative" value={neg.length} sub={(100 - posRate) + "% concerns"} icon="▼" color={N} />
                <StatCard label="Avg Rating" value={avgRating} sub="Out of 5 stars" icon="★" color="#d97706" />
                <StatCard label="Categories" value={CATEGORIES.length - 1} sub="Topic areas" icon="◈" color="#6366f1" />
              </div>

              {/* Charts Row */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 280px", gap: "20px", marginBottom: "24px" }}>
                {/* Trend Chart */}
                <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "16px", padding: "22px" }}>
                  <div style={{ fontSize: "13px", fontWeight: "700", color: TEXT, marginBottom: "4px" }}>Monthly Trend</div>
                  <div style={{ fontSize: "11px", color: MUTED, marginBottom: "16px" }}>Positive vs Negative over time</div>
                  <ResponsiveContainer width="100%" height={190}>
                    <AreaChart data={trendData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <defs>
                        <linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={P} stopOpacity={0.25} />
                          <stop offset="95%" stopColor={P} stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="ng" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={N} stopOpacity={0.2} />
                          <stop offset="95%" stopColor={N} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke={BORDER} strokeDasharray="3 3" />
                      <XAxis dataKey="month" tick={{ fill: MUTED, fontSize: 11 }} />
                      <YAxis tick={{ fill: MUTED, fontSize: 10 }} />
                      <Tooltip content={<CT />} />
                      <Area type="monotone" dataKey="positive" name="Positive" stroke={P} fill="url(#pg)" strokeWidth={2.5} dot={false} />
                      <Area type="monotone" dataKey="negative" name="Negative" stroke={N} fill="url(#ng)" strokeWidth={2.5} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Category Chart */}
                <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "16px", padding: "22px" }}>
                  <div style={{ fontSize: "13px", fontWeight: "700", color: TEXT, marginBottom: "4px" }}>By Category</div>
                  <div style={{ fontSize: "11px", color: MUTED, marginBottom: "16px" }}>Breakdown per topic area</div>
                  <ResponsiveContainer width="100%" height={190}>
                    <BarChart data={catBreakdown} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <CartesianGrid stroke={BORDER} strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fill: MUTED, fontSize: 9 }} />
                      <YAxis tick={{ fill: MUTED, fontSize: 10 }} />
                      <Tooltip content={<CT />} />
                      <Bar dataKey="pos" name="Positive" fill={P} radius={[4, 4, 0, 0]} />
                      <Bar dataKey="neg" name="Negative" fill={N} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Pie Chart */}
                <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "16px", padding: "22px" }}>
                  <div style={{ fontSize: "13px", fontWeight: "700", color: TEXT, marginBottom: "4px" }}>Sentiment Split</div>
                  <div style={{ fontSize: "11px", color: MUTED, marginBottom: "10px" }}>Positive vs Negative</div>
                  <ResponsiveContainer width="100%" height={150}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                        {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                      </Pie>
                      <Tooltip content={<CT />} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display: "flex", justifyContent: "center", gap: "16px", marginTop: "4px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: MUTED }}>
                      <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: P }} /> Positive ({posRate}%)
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: MUTED }}>
                      <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: N }} /> Negative ({100 - posRate}%)
                    </div>
                  </div>
                </div>
              </div>

              {/* Split Feed */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "14px" }}>
                    <div style={{ width: "4px", height: "20px", background: P, borderRadius: "2px" }} />
                    <div style={{ fontSize: "14px", fontWeight: "700", color: TEXT }}>Recent Positive</div>
                    <span style={{ background: "#d1fae5", color: "#065f46", borderRadius: "99px", padding: "2px 10px", fontSize: "11px", fontWeight: "700" }}>{pos.length}</span>
                  </div>
                  {pos.slice(0, 3).map((f, i) => <FeedbackCard key={f.id} item={f} delay={i * 0.05} />)}
                  <button onClick={() => setActivePage("positive")} style={{ background: "none", border: `1px solid ${BORDER}`, borderRadius: "10px", padding: "10px", width: "100%", color: MUTED, fontSize: "13px", cursor: "pointer", fontFamily: "inherit" }}>View all {pos.length} positive →</button>
                </div>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "14px" }}>
                    <div style={{ width: "4px", height: "20px", background: N, borderRadius: "2px" }} />
                    <div style={{ fontSize: "14px", fontWeight: "700", color: TEXT }}>Recent Negative</div>
                    <span style={{ background: "#ffe4e6", color: "#9f1239", borderRadius: "99px", padding: "2px 10px", fontSize: "11px", fontWeight: "700" }}>{neg.length}</span>
                  </div>
                  {neg.slice(0, 3).map((f, i) => <FeedbackCard key={f.id} item={f} delay={i * 0.05} />)}
                  <button onClick={() => setActivePage("negative")} style={{ background: "none", border: `1px solid ${BORDER}`, borderRadius: "10px", padding: "10px", width: "100%", color: MUTED, fontSize: "13px", cursor: "pointer", fontFamily: "inherit" }}>View all {neg.length} negative →</button>
                </div>
              </div>
            </>
          )}

          {/* ── POSITIVE / NEGATIVE / ALL PAGES ── */}
          {activePage !== "dashboard" && (
            <>
              {/* Page Banner */}
              {activePage === "positive" && (
                <div style={{ background: "linear-gradient(135deg, #d1fae5, #a7f3d0)", border: "1px solid #6ee7b7", borderRadius: "16px", padding: "24px 28px", marginBottom: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "28px", fontWeight: "800", color: "#065f46" }}>▲ Positive Feedback</div>
                    <div style={{ fontSize: "13px", color: "#047857", marginTop: "4px" }}>Students who praised the teaching — {pos.length} entries collected</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: "48px", fontWeight: "900", color: "#059669", lineHeight: 1 }}>{posRate}%</div>
                    <div style={{ fontSize: "12px", color: "#047857" }}>Satisfaction Rate</div>
                  </div>
                </div>
              )}
              {activePage === "negative" && (
                <div style={{ background: "linear-gradient(135deg, #ffe4e6, #fecdd3)", border: "1px solid #fda4af", borderRadius: "16px", padding: "24px 28px", marginBottom: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "28px", fontWeight: "800", color: "#9f1239" }}>▼ Negative Feedback</div>
                    <div style={{ fontSize: "13px", color: "#be123c", marginTop: "4px" }}>Areas requiring immediate attention — {neg.length} concerns raised</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: "48px", fontWeight: "900", color: "#e11d48", lineHeight: 1 }}>{neg.length}</div>
                    <div style={{ fontSize: "12px", color: "#be123c" }}>Issues Flagged</div>
                  </div>
                </div>
              )}
              {activePage === "all" && (
                <div style={{ background: "linear-gradient(135deg, #fef3c7, #fde68a)", border: "1px solid #fcd34d", borderRadius: "16px", padding: "24px 28px", marginBottom: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "28px", fontWeight: "800", color: "#78350f" }}>≡ All Feedback</div>
                    <div style={{ fontSize: "13px", color: "#92400e", marginTop: "4px" }}>Complete feedback repository — {feedback.length} total entries</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: "48px", fontWeight: "900", color: ACCENT, lineHeight: 1 }}>{avgRating}★</div>
                    <div style={{ fontSize: "12px", color: "#92400e" }}>Average Rating</div>
                  </div>
                </div>
              )}

              {/* Filters */}
              <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: "14px", padding: "16px 20px", marginBottom: "20px", display: "flex", gap: "14px", flexWrap: "wrap", alignItems: "center" }}>
                <span style={{ fontSize: "11px", color: MUTED, letterSpacing: "1px" }}>FILTER:</span>
                <select value={filterCat} onChange={e => setFilterCat(e.target.value)} style={{ padding: "7px 12px", border: `1px solid ${BORDER}`, borderRadius: "8px", fontSize: "12px", color: TEXT, background: BG, fontFamily: "inherit", outline: "none" }}>
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
                <select value={filterRating} onChange={e => setFilterRating(e.target.value)} style={{ padding: "7px 12px", border: `1px solid ${BORDER}`, borderRadius: "8px", fontSize: "12px", color: TEXT, background: BG, fontFamily: "inherit", outline: "none" }}>
                  {RATINGS.map(r => <option key={r}>{r}</option>)}
                </select>
                <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "7px 12px", border: `1px solid ${BORDER}`, borderRadius: "8px", fontSize: "12px", color: TEXT, background: BG, fontFamily: "inherit", outline: "none" }}>
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                  <option value="highest">Highest Rating</option>
                  <option value="lowest">Lowest Rating</option>
                </select>
                <span style={{ marginLeft: "auto", fontSize: "12px", color: MUTED }}>{pageFiltered.length} results</span>
              </div>

              {/* Cards */}
              {pageFiltered.length === 0 ? (
                <div style={{ textAlign: "center", padding: "60px", color: MUTED }}>
                  <div style={{ fontSize: "40px", marginBottom: "12px" }}>○</div>
                  <div>No feedback matches your filters.</div>
                </div>
              ) : (
                <div style={{ columns: "2", gap: "0" }}>
                  {pageFiltered.map((f, i) => (
                    <div key={f.id} style={{ breakInside: "avoid", paddingRight: i % 2 === 0 ? "10px" : "0", paddingLeft: i % 2 !== 0 ? "10px" : "0" }}>
                      <FeedbackCard item={f} delay={Math.min(i * 0.03, 0.3)} />
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {showModal && <AddModal onClose={() => setShowModal(false)} onAdd={f => setFeedback(prev => [f, ...prev])} />}

      <style>{`
        @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        * { box-sizing: border-box; }
        select:focus, input:focus { border-color: ${ACCENT} !important; box-shadow: 0 0 0 3px ${ACCENT}22; }
      `}</style>
    </div>
  );
}
