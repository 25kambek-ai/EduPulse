# AI Education Dashboards

Three professional React dashboards for education analytics.

## Dashboards Included

| Dashboard | Description |
|---|---|
| 📊 Feedback Dashboard | Positive & Negative student feedback with charts, filters, add form |
| 🎓 Education Analytics | AI-powered feedback analyzer using Claude API |
| σ Logistic Regression | Full ML model training, ROC curve, confusion matrix |

## Setup & Run

### 1. Install dependencies
```bash
npm install
```

### 2. Start development server
```bash
npm start
```
Opens at **http://localhost:3000**

## Notes

- **Education Analytics** requires an Anthropic API key configured (the API call is made from the browser).
- **Logistic Regression** runs entirely in-browser — no backend needed.
- **Feedback Dashboard** is fully self-contained with sample data.

## Project Structure

```
src/
├── App.jsx                        # Home screen with navigation
├── index.js                       # React entry point
├── FeedbackDashboard.jsx          # Positive/Negative feedback dashboard
├── EducationAnalytics.jsx         # AI feedback analyzer
└── LogisticRegressionDashboard.jsx # ML dashboard
public/
└── index.html
package.json
```
